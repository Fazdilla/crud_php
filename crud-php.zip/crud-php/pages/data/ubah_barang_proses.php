<?php
include "../../conf/conn.php";
if($_POST)
{
$id = $_POST['id'];
$nama_barang = $_POST['nama_barang'];
$harga = $_POST['harga'];
$query = ("UPDATE barang SET nama_barang='$nama_barang',harga='$harga'WHERE id ='$id'");
if(!mysqli_query($koneksi, "$query")){
die(mysqli_error($koneksi));
}else{
echo '<script>alert("Data Berhasil Diubah !!!");
window.location.href="../../index.php?page=data"</script>';
}
}
?>